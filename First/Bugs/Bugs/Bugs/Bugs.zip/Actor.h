#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
class StudentWorld;
class Compiler;
class Food;
class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, Direction dir = right, unsigned int depth = 0 , StudentWorld *sw = nullptr);
	virtual ~Actor();
	
	virtual void doSomething();
	bool checkAlive();
	void setDead();
	Actor* getAnActorAtTheProposedLocation(int X, int Y);
	StudentWorld * myWorld() const;
	void setMoved();
	void setUnmoved();
	bool checkMoved();
	virtual bool blockAnt();
	virtual bool isEdible();
	virtual void eatenByHopper(){}
	void setMyHit(int m);
	void decrease(int m = 1);
	void increase(int m);
	int getMyHit();
	virtual void setPoisoned(){}
	virtual void setWatered(){}
	virtual void bittenByAdult(){}
private:
	bool m_alive;
	StudentWorld *my_sw;
	bool moved;
	int m_hit;
};
class Poison : public Actor
{
public:
	Poison(int startX, int startY, StudentWorld *sw);
	virtual void doSomething();
};


class Water : public Actor
{
public:
	Water(int startX, int startY, StudentWorld *sw);
	virtual void doSomething();

};

class Pebble : public Actor
{
public:
	Pebble(int startX, int startY, StudentWorld *sw);
	virtual bool blockAnt();
};


class Food : public Actor
{
public:
	Food(int startX, int startY , StudentWorld * sw);
	Food(int startX, int startY, int volumn, StudentWorld *sw);
	virtual void doSomething();
	virtual bool isEdible();
	virtual void eatenByHopper();
private:
	
	
};
class Pheromone: public Actor
{
public:
	Pheromone(int image, int startX, int startY, int colonyType, StudentWorld * sw);
	virtual void doSomething();
	void add();
	int getColonyType();
private:
	
	int m_colony;
};

class Insect : public Actor
{
public:
	Insect(int imageID, int startX, int startY, int volumn, Direction dir = Direction(rand() % 4 + 1), StudentWorld *sw = nullptr);
	virtual ~Insect();
	virtual void doSomething();
	bool checkStunned();
	virtual void setStunned();
	void setRandomDis();
	int getRemainingDistance();
	int eatOneTime();
	virtual bool bite();
	bool checkbitten();
	virtual void setPoisoned();
	void setCounterValue(int m);
	void decreaseStunnedTime();
	void setUnStunned();
	bool goodStatus();
	void setRemainingDis(int m);
	virtual bool move();
	void bittenByAnt();
	virtual void setMemory(int X, int Y);
	int getMemoryX();
	int getMemoryY();
	virtual void pickRandomDirection();
	virtual bool isBlocked(int X, int Y);
	Actor* findFood(int X, int Y);
	void eat(Actor* a);
	void setUnBitten();
	virtual void setWatered();
	virtual void bittenByAdult();
	void setBitten();
	
private:
	bool m_stunned;
	int remianning_stunned_time;
	int remaining_distance;
	int m_eatOneTime;
	bool m_bitten;
	int m_ic;
	int memoryX;
	int memoryY;
	
};
class Anthill : public Insect
{
public:
	Anthill(int startX, int startY, int colonyType, Compiler p , StudentWorld *sw);
	virtual void doSomething();
	void produce();
	int getColonyType();
	int getAntImage();
	int getPheromoneImage();
	virtual bool move();
	virtual void setStunned(){}
	virtual void setMemory(int X, int Y) {}
	virtual void setPoisoned(){}
	virtual void setWatered(){}
	virtual void bittenByAdult() {}
private:
	int m_colony;
	int antImage;
	int pheromoneImage;
	// compile object
};

class Ant : public Insect
{
public:
	Ant(int image, int startX, int startY, int colonyType,Compiler* p , StudentWorld *sw);
	virtual void doSomething();
	void pickup();
	void drop();
	int getColonyType();
	virtual bool bite();
	int getLastValue();
	int amountHold();
	Compiler* getCompiler();

private:
	int m_colony;
	int m_capacity;
	int last_random_value;
	int m_hold;
	Compiler *myC;
	
};
class Grasshopper : public Insect
{
public:
	Grasshopper(int imageID, int startX, int startY, int volumn, StudentWorld *sw); // Volumn is how many units it can eat one time
	virtual ~Grasshopper();
	virtual void doSomething() = 0;
	virtual bool move();
	bool haveARest();
};
class Baby_Grasshopper : public Grasshopper
{
public:
	Baby_Grasshopper(int startX, int startY, StudentWorld *sw);
	virtual void doSomething();
private:
	int m_capacity;
	
};
class Adult_Grasshopper : public Grasshopper
{
public:
	Adult_Grasshopper(int startX, int startY, StudentWorld *sw);
	virtual void doSomething();
	virtual bool bite();
	virtual void setPoisoned(){}
	virtual void setWatered(){}
	bool decideToBite();
	bool decideToJump();
private:
	


};
#endif // ACTOR_H_
