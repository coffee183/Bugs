#include "StudentWorld.h"
#include "Actor.h"
#include "Field.h"
#include <string>
#include "Compiler.h"
#include "GameController.h"
#include <list>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

StudentWorld::StudentWorld(string assetDir)
	: GameWorld(assetDir), m_Anthill(0), tickCount(0)
{}
StudentWorld::~StudentWorld()
{
	cleanUp();	
}
void StudentWorld::poisonTheList(int X, int Y)
{
	list<Actor*>::iterator p = myActors[X][Y].begin();
	for (; p != myActors[X][Y].end(); p++)
		(*p)->setPoisoned();
}

Actor * StudentWorld::getFirstObjectPointer(int X, int Y)
{
	if (myActors[X][Y].empty())
		return nullptr;
	list <Actor *>::iterator p = myActors[X][Y].begin();
	return (*p);
}
void StudentWorld::removeActor(int X, int Y, Actor* m)
{
	list<Actor *>::iterator p = myActors[X][Y].begin();
	while ((myActors[X][Y].size() != 1) && (p != myActors[X][Y].end()))
	{
		//cerr << "Got in here now-------"<< endl;		
		if ((*p) == m)
			break;
		else
			++p;
	}
	//cerr << "************************Got in here now-------" << endl;
	myActors[X][Y].erase(p);
	//cerr << "notbad"<< endl;
}
void StudentWorld::addActor(int X, int Y, Actor* m)
{
	Actor* p = m;
	myActors[X][Y].push_back(p);
}
void StudentWorld::addFoodObject(int X, int Y)
{
	myActors[X][Y].push_front(new Food(X, Y, 100, this));
	cerr << "��������������������������������������������������������There was no food before, I add 100--------------------------------" << endl;
	cerr << "my location is " << X << "                 " << Y << endl;
}
void StudentWorld::waterTheList(int X, int Y)
{
	list<Actor*>::iterator p = myActors[X][Y].begin();
	for (; p != myActors[X][Y].end(); p++)
		(*p)->setWatered();
}



int StudentWorld::loadMyField()  
{
	Field f;
	string fieldFile = getFieldFilename();
	string error;
	cerr << "Here is Ok!" << endl;
	if (f.loadField(fieldFile, error) != Field::LoadResult::load_success) 
	{
		setError(fieldFile + " " + error);
		cerr << error << endl;
		return false;
	}
	
	Field::FieldItem item;
	for (int i = 0; i < VIEW_WIDTH; i++)
	{
		
		for (int j = 0; j < VIEW_HEIGHT; j++)
		{
			
			item = f.getContentsOf(i, j);
			if (item == Field::FieldItem::rock)
			{
				myActors[i][j].push_back(new Pebble(i, j ,this));
			}
				
			else if (item == Field::FieldItem::water)
			{
				myActors[i][j].push_back(new Water(i, j,this));
			}
			
			else if (item == Field::FieldItem::food)
			{
				myActors[i][j].push_back(new Food(i, j,this));
			}
			
			else if (item == Field::FieldItem::poison)
			{
				myActors[i][j].push_back(new Poison(i, j,this));
				//cerr << "Poison" << endl;
			}
			
			/*else if (item == Field::FieldItem::anthill0)
			myActors[i][j].push_back(new Anthill(i, j, 0, c0));
			else if (item == Field::FieldItem::anthill1)
			myActors[i][j].push_back(new Anthill(i, j, 1, c1));
			else if (item == Field::FieldItem::anthill2)
			myActors[i][j].push_back(new Anthill(i, j, 2, c2));
			else if (item == Field::FieldItem::anthill3)
			myActors[i][j].push_back(new Anthill(i,j, 3, c3));*/
			else if (item == Field::FieldItem::grasshopper)
			{
				myActors[i][j].push_back(new Baby_Grasshopper(i, j, this));
			}
		}
	}
	cerr << "I'm done loading!" << endl;
	return GWSTATUS_CONTINUE_GAME;
}
int StudentWorld::init()
{

	tickCount = 0;
	list<Actor *>::iterator p;
	if (loadMyField() == GWSTATUS_CONTINUE_GAME)
	{	
		return GWSTATUS_CONTINUE_GAME;
	}		
	else
		return GWSTATUS_LEVEL_ERROR;

}

int StudentWorld::move()
{

	tickCount++;
	cerr << "I have run " << tickCount << " times" << endl;
	for (int i = 0; i < 64; i++)
	{
		for (int j = 0; j < 64; j++)
		{
			if (!myActors[i][j].empty())
			{

				list<Actor *>::iterator p = myActors[i][j].begin();
				while (p != myActors[i][j].end())
				{

					if ((!(*p)->checkMoved()) && ((*p)->checkAlive()))
					{

						list<Actor *>::iterator q = p;
						p++;
						(*q)->doSomething();

					}
					else
						++p;
				}
			}
		}
	}
	for (int i = 0; i < 64; i++)
	{
		for (int j = 0; j < 64; j++)
		{
			if (!myActors[i][j].empty())
			{

				list<Actor *>::iterator p = myActors[i][j].begin();
				while (p != myActors[i][j].end())
				{
					if (!(*p)->checkAlive())
					{
						delete (*p);
						*p = nullptr;
						p = myActors[i][j].erase(p);
						cerr << "____________here____________________________" << endl;

					}
					else
					{
						(*p)->setUnmoved();
						++p;
					}
				}
			}
		}
	}
	if (tickCount < 2000)
		return GWSTATUS_CONTINUE_GAME;
	else
		return GWSTATUS_NO_WINNER;
}
void StudentWorld::cleanUp()
{
	for (int i = 0; i < 64; i++)
	{
		for (int j = 0; j < 64; j++)
		{
			if (!myActors[i][j].empty())
			{
				list<Actor*>::iterator p = myActors[i][j].begin();
				while (p != myActors[i][j].end())
				{
					delete (*p);
					*p = nullptr;
					p = myActors[i][j].erase(p);
				}
			}
			
		}

	}
}