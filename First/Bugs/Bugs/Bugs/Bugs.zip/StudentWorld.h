#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <list>
#include <string>
class Actor;
class Field;
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir);
	virtual ~StudentWorld();
	virtual int init();

	virtual int move();

	virtual void cleanUp();

	int loadMyField();
	Actor* getFirstObjectPointer(int X, int Y);
	void removeActor(int X, int Y, Actor* m);
	void addActor(int X, int Y, Actor* m);
	void poisonTheList(int X, int Y);
	void addFoodObject(int X, int Y);
	void waterTheList(int X, int Y);

private:
	std::list<Actor*> myActors[64][64];
	int m_Anthill;
	int tickCount;

};



#endif // STUDENTWORLD_H_
