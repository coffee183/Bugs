#include "Actor.h"
#include "StudentWorld.h"
#include "Compiler.h"
using namespace std;

Actor::Actor(int imageID, int startX, int startY, Direction dir, unsigned int depth, StudentWorld *sw)
	:GraphObject(imageID, startX, startY, dir, depth), m_alive(true),moved(false),my_sw(sw), m_hit(0)
{}
Actor::~Actor()
{}

bool Actor::checkAlive()
{
	return (m_alive == true);
}
bool Actor::blockAnt()
{
	return false;
}
bool Actor::isEdible()
{
	return false;
}

void Actor::setDead()
{
	m_alive = false;
}

void Actor::doSomething()
{
	setMoved();
}
Actor* Actor::getAnActorAtTheProposedLocation(int X, int Y)
{
	return (my_sw->getFirstObjectPointer(X, Y));
}
void Actor::setMoved()
{
	moved = true;
}
void Actor::setUnmoved()
{
	moved = false;
}
bool Actor::checkMoved()
{
	return (moved == true);
}
StudentWorld * Actor::myWorld() const
{
	return my_sw;
}
void Actor::setMyHit(int m)
{
	m_hit = m;
}
void Actor::decrease(int m)
{
	m_hit -= m;
}
void Actor::increase(int m)
{
	m_hit += m;
}
int Actor::getMyHit()
{
	return m_hit;
}

Poison::Poison(int startX, int startY, StudentWorld *sw)
	: Actor(IID_POISON, startX, startY, right, 2, sw)
{}

void Poison::doSomething()
{
	setMoved();
	myWorld()->poisonTheList(getX(), getY());
}
Water::Water(int startX, int startY, StudentWorld *sw)
	: Actor(IID_WATER_POOL, startX, startY, right, 2, sw)
{}
void Water::doSomething()
{
	myWorld()->waterTheList(getX(), getY());
}
Pebble::Pebble(int startX, int startY, StudentWorld* sw)
	:Actor(IID_ROCK, startX, startY, right, 1, sw)
{}
bool Pebble::blockAnt()
{
	return true;
}

Food::Food(int startX, int startY, StudentWorld *sw)
	: Actor(IID_FOOD, startX, startY, right, 2, sw)
{
	setMyHit(6000);
}
Food::Food(int startX, int startY, int volumn, StudentWorld *sw)
	: Actor(IID_FOOD, startX, startY, right, 2, sw)
{
	setMyHit(volumn);
}

bool Food::isEdible()
{
	return true;
}

void Food::eatenByHopper()
{
	if (getMyHit() >= 200)
		decrease(200);
	else
		setMyHit(0);
}
void Food::doSomething()
{
	setMoved();
	if (getMyHit() <= 0)
	{
		setDead();
		cerr << "-----------------------------i have no food now--------------------" << endl;
	}
}
Pheromone::Pheromone(int image, int startX, int startY, int colonyType, StudentWorld *sw)
	: Actor(image, startX, startY, right, 2, sw), m_colony(colonyType)
{
	setMyHit(256);
}
void Pheromone::doSomething()
{
	setMoved();
	decrease();
	if (getMyHit() <= 0)
		setDead();
}
int Pheromone::getColonyType()
{
	return m_colony;
}
void Pheromone::add()
{
	if (getMyHit() <= 512)
		increase(256);  //check if there are more than 768 of that pheromone
	else
		setMyHit(768);
}

Insect::Insect(int imageID, int startX, int startY, int volumn, Direction dir, StudentWorld *sw)
	:Actor(imageID, startX, startY, dir, 1, sw), m_eatOneTime(volumn), m_stunned(false),
	remianning_stunned_time(0), m_bitten(false), m_ic(0)
{
	setRandomDis();
	setMemory(-1, -1);
}
Insect::~Insect()
{
	Actor* ap = findFood(getX(), getY());
	if (ap != nullptr)
	{
		ap->increase(100);
		cerr << "*************There exists food, I add 100******************************" << endl;
	}
	else
	{
		myWorld()->addFoodObject(getX(), getY());
	}
}
void Insect::doSomething()
{

}
void Insect::bittenByAdult()
{
	decrease(50);
	setBitten();
}
void Insect::setBitten()
{
	m_bitten = true;
}
bool Insect::checkStunned()
{
	return (m_stunned == true);
}
void Insect::setStunned()
{
	m_stunned = true;
	remianning_stunned_time += 2;
}
void Insect::bittenByAnt()
{
	m_bitten = true;
	decrease(15);
}
bool Insect::goodStatus()
{
	decrease();
	if (getMyHit() <= 0)
	{
		setDead();
		return false;
	}
	if (checkStunned())
	{
		//cerr << "I'm stunned" << endl;
		decreaseStunnedTime();
		if (remianning_stunned_time == 0)
			setUnStunned();
		return false;
	}
	return true;

}
Actor* Insect::findFood(int X, int Y)
{

	Actor* ap = getAnActorAtTheProposedLocation(X, Y);
	if (ap != nullptr)
	{
		if (ap->isEdible())
		{
			return ap;
		}
	}
	return nullptr;
}
void Insect::setRandomDis()
{
	remaining_distance = randInt(2, 10);
}
int Insect::getRemainingDistance()
{
	return remaining_distance;
}
void Insect::eat(Actor* a)  //TO DO: eat the food object on this point
{
	
	if (a->getMyHit() >= eatOneTime())
		increase(eatOneTime());
	else
		increase(a->getMyHit());
}
void Insect::setPoisoned()
{
	if (getX() == getMemoryX() && getY() == getMemoryY())
		return;
	setStunned();
	decrease(150);
	if (getMyHit() <= 0)
		setDead();
	setMemory(getX(), getY());
	cerr << "I got poisoned!------------now my hit point is " << getMyHit()<<endl;
	
}
void Insect::setWatered()
{
	if (getX() == getMemoryX() && getY() == getMemoryY())
		return;
	setStunned();
	setMemory(getX(), getY());
	cerr << "I'm stunned by Water!" << endl;
}
int Insect::eatOneTime()
{
	return m_eatOneTime;
}
bool Insect::checkbitten()
{
	return m_bitten == true;
}

bool Insect::bite()
{
	return true;
}

void Insect::setCounterValue(int m)
{
	m_ic = m;
}
void Insect::decreaseStunnedTime()
{
	remianning_stunned_time--;
}
void Insect::setUnStunned()
{
	m_stunned = false;
}
void Insect::setRemainingDis(int m)
{
	remaining_distance = m;
}
void Insect::setMemory(int X, int Y)
{
	memoryX = X;
	memoryY = Y;
}
int Insect::getMemoryX()
{
	return memoryX;
}
int Insect::getMemoryY()
{
	return memoryY;
}
void Insect::pickRandomDirection()
{
	Direction d = Direction(rand() % 4 + 1); 
	setDirection(d);
}

bool Insect::move()
{

	int X = getX();
	int Y = getY();
	if (getRemainingDistance() <= 0)
	{
		pickRandomDirection();
		setRandomDis();
	}
	
	if (getDirection() == left && !isBlocked(getX() - 1, getY()))
		
	{
		moveTo(getX() - 1, getY());
		myWorld()->addActor(X - 1, Y, this);
		myWorld()->removeActor(X, Y, this);		
		remaining_distance--;
		return true;
	}
	else if (getDirection() == right && !isBlocked(getX() + 1, getY()))		
	{
		
		moveTo(getX() + 1, getY());
		myWorld()->addActor(X + 1, Y, this);
		myWorld()->removeActor(X, Y, this);
		remaining_distance--;
		return true;
	}
	else if (getDirection() == up && !isBlocked(getX(), getY() + 1))
	{
		moveTo(getX(), getY() + 1);
		myWorld()->addActor(X, Y + 1, this);
		myWorld()->removeActor(X, Y, this);		
		remaining_distance--;
		return true;
	}
	else if (getDirection() == down && !isBlocked(getX(), getY() - 1))
	{
		moveTo(getX(), getY() - 1);
		myWorld()->addActor(X, Y - 1, this);
		myWorld()->removeActor(X, Y, this);		
		remaining_distance--;
		return true;
	}
	return false;//blocked	
}
bool Insect::isBlocked(int X, int Y)
{
	Actor* ap = getAnActorAtTheProposedLocation(X, Y);
	if (ap != nullptr)
	{	
		if (ap ->blockAnt())
		{
			return true;
		}
	}
	return false;
}
void Insect::setUnBitten()
{
	m_bitten = false;
}
Anthill::Anthill(int startX, int startY, int colonyType, Compiler p, StudentWorld *sw)
	: Insect(IID_ANT_HILL, startX, startY, 10000, right, sw), m_colony(colonyType)
{
	setMyHit(8999);
}
void Anthill::doSomething()
{
	setMoved();
	//if (goodStatus())
	//{
	//}
	//// TO DO: see if there is food here
	//// if food.getContent() >eatOneTime()
	//if (true)
	//{
	//	eat();
	//}

	//else
	//{
	//	;// eat(food.getContent())
	//}
	//if (checkHitPt() >= 2000)
	//{
	//	produce();
	//}
}

bool Anthill::move()
{
	return false;
}
void Anthill::produce()
{
	decrease(1500);
	//TO DO: ask sw to produce an ant
}
int Anthill::getColonyType()
{
	return m_colony;
}
int Anthill::getAntImage()
{
	return antImage;
}
int Anthill::getPheromoneImage()
{
	return pheromoneImage;
}

Ant::Ant(int image, int startX, int startY, int colonyType, Compiler* p, StudentWorld *sw)
	: Insect(image, startX, startY, 400, right, sw), m_capacity(1800), m_colony(colonyType),
	m_hold(0), last_random_value(0), myC(p)
{
	setMyHit(1500);
}
void Ant::drop()
{
	// TO DO: add the food object on this point by m_hold;
	m_hold = 0;
}

void Ant::doSomething()
{
	setMoved();
	if (goodStatus())
	{
		;// TO Do: compiler!
	}


}
Compiler* Ant::getCompiler()
{
	return myC;
}
int Ant::amountHold()
{
	return m_hold;
}
int Ant::getColonyType()
{
	return m_colony;
}
int Ant::getLastValue()
{
	return last_random_value;
}
void Ant::pickup()
{
	if (true) // the food object here has more than 400 units of food
	{
		m_hold += 400;   // do something to food object
	}

	else
	{
		m_hold += 0; // TO DO: add the amount of food there  getContent()
	}
}



bool Ant::bite()
{
	return true;
}

Grasshopper::Grasshopper(int imageID, int startX, int startY, int volumn, StudentWorld *sw) // Volumn is how many units it can eat one time
	: Insect(imageID, startX, startY, volumn, right, sw)
{}
Grasshopper::~Grasshopper()
{}


bool Grasshopper::haveARest()
{
	int n = randInt(0, 1);
	if (n == 0)
		return true;
	else
		return false;
}
bool Grasshopper::move()
{
	if (!Insect::move())
	{
		setStunned();
		setRemainingDis(0);
		pickRandomDirection();
		setRandomDis();
		return false;
	}
	else
	{
		setStunned();
		setUnBitten();
		setMemory(-1, -1);
		return true;
	}
}

Baby_Grasshopper::Baby_Grasshopper(int startX, int startY, StudentWorld *sw)
	: Grasshopper(IID_BABY_GRASSHOPPER, startX, startY, 200, sw), m_capacity(1600)
{
	setMyHit(500);
}

void Baby_Grasshopper::doSomething()
{
	setMoved();
	if (goodStatus())
	{
		if (getMyHit() >= m_capacity)
		{
			setDead();
			myWorld()->addActor(getX(), getY(), new Adult_Grasshopper(getX(), getY(), myWorld()));
			cerr << "_____________________________I am big+++++++++++++++++++++++++++++++" << endl;
			return;
		}
		Actor* ap = findFood(getX(), getY());
		if (ap!=nullptr)
		{
			
			eat(ap);
			ap->eatenByHopper();
			cerr << "Now my hit points is " << getMyHit() << endl;
			if (haveARest()) 
			{
				return;
			}
		}
		move();				
	}
}

Adult_Grasshopper::Adult_Grasshopper(int startX, int startY, StudentWorld *sw)
	: Grasshopper(IID_ADULT_GRASSHOPPER, startX, startY, 200, sw)
{
	setMyHit(1600);
}
bool Adult_Grasshopper::decideToBite()
{
	int n = randInt(0, 2);
	if (n == 0)
		return true;
	else
		return false;
}
bool Adult_Grasshopper::bite()
{
	return true;
}
bool Adult_Grasshopper::decideToJump()
{
	int n = randInt(0, 9);
	if (n == 0)
		return true;
	else
		return false;
}
void Adult_Grasshopper::doSomething()
{
	if (goodStatus())
	{
		
		if (decideToBite())
		{
			if (true) //TO DO: ask the object to lose 50, setStunned  if (bite())
				return;
		}
		
		if (decideToJump())
		{
			if (true) //TO Do: if it jumped successfully, it can't jump if there is no available place, set stunned  if (jump())
				return;
		}
		

	}
}